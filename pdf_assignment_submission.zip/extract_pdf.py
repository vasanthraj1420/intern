
import fitz  # PyMuPDF
import os
import json

def extract_pdf_content(pdf_path, output_image_dir, output_json_path):
    os.makedirs(output_image_dir, exist_ok=True)
    doc = fitz.open(pdf_path)
    output = []

    for page_number in range(len(doc)):
        page = doc[page_number]
        text = page.get_text()
        image_list = []

        for img_index, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image_ext = base_image["ext"]
            image_filename = f"page{page_number+1}_image{img_index+1}.{image_ext}"
            image_path = os.path.join(output_image_dir, image_filename)
            with open(image_path, "wb") as image_file:
                image_file.write(image_bytes)
            image_list.append(image_path)

        output.append({
            "page": page_number + 1,
            "text": text.strip(),
            "images": image_list
        })

    with open(output_json_path, "w", encoding="utf-8") as json_file:
        json.dump(output, json_file, indent=4)

# Example usage:
# extract_pdf_content("sample.pdf", "images", "output.json")
